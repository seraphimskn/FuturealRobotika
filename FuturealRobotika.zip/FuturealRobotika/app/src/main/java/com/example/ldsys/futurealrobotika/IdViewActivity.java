package com.example.ldsys.futurealrobotika;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class IdViewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_id_view);
    }
}
